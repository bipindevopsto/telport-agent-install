# Teleport AWS Terraform

This section of the Teleport Github repo contains AWS Terraform definitions for two Teleport cluster configurations.

- A simple starter Teleport cluster to, quickly and cost-effectively, demo or POC Teleport on a single node (auth, proxy, and node processes running on one t3.nano ec2 instance).
- A production worthy high-availability auto-scaling Teleport Cluster. This cluster makes use of several AWS technologies, provisioned and configured using Terraform.

If you are planning on using our Terraform example in production, please reference the high-availability auto-scaling Teleport Cluster for best practices. Our Production Guide outlines in-depth details on how to run Teleport in production.

## Prerequisites

We recommend familiarizing yourself with the following resources prior to reviewing our Terraform examples:

- [Teleport Architecture](https://goteleport.com/teleport/docs/architecture/overview/)
- [Admin Guide](https://gravitational.com/teleport/docs/admin-guide/)

In order to spin up AWS resources using these Terraform examples, you need the following software:

- terraform v0.12+ [install docs](https://learn.hashicorp.com/terraform/getting-started/install.html)
- awscli v1.14+ [install docs](https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-install.html)

## Projects

- Starter Teleport Cluster
  - [Get Started](starter-cluster/README.md)

- HA Auto-Scaling Teleport Cluster
  - [Get Started](ha-autoscale-cluster/README.md)

## How to get help

If you're having trouble, check out our [Discourse community](https://community.gravitational.com).

For bugs related to this code, please [open an issue](https://github.com/gravitational/teleport/issues/new/choose).

## Public Teleport AMI IDs

Please [see the AMIS.md file](AMIS.md) for a list of public Teleport AMI IDs that you can use.
